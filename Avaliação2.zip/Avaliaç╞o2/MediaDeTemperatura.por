programa{
    funcao inicio(){
        real temperaturas[5] 
        real soma = 0.0, media
        inteiro i

        escreva("--- Registro de Temperaturas ---\n")

        para (i = 0; i < 5; i++){
            escreva("Digite a temperatura do ", i + 1, "� dia: ")
            leia(temperaturas[i])
            
            soma = soma + temperaturas[i] 
        }

        media = soma / 5.0

        escreva("\n--- Resultado ---\n")
        escreva("A m�dia geral das temperaturas da semana foi de: ", media, " graus.\n")
    }
}
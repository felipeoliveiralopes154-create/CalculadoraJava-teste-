programa{
    funcao inicio(){
        inteiro tabuleiro[3][3] = {
            {0, 0, 1},
            {0, 0, 0},
            {1, 0, 0}
        }
        
        inteiro linha, coluna, tentativa
        inteiro acertos = 0

        escreva("=== MINI-JOGO BATALHA NAVAL ===\n")
        escreva("Existem 2 navios escondidos num mapa 3x3.\n")
        escreva("Voc� tem 3 chances para atirar!\n\n")

        para (tentativa = 1; tentativa <= 3; tentativa++){
            escreva("--- Tiro ", tentativa, " de 3 ---\n")
            escreva("Digite a linha para atirar (0 a 2): ")
            leia(linha)
            escreva("Digite a coluna para atirar (0 a 2): ")
            leia(coluna)

            se (tabuleiro[linha][coluna] == 1){
                escreva("BOOM! Voc� acertou em cheio um navio!\n\n")
                
                tabuleiro[linha][coluna] = 0 
                acertos = acertos + 1
            }
            senao{
                escreva("SPLASH! Voc� acertou apenas a �gua.\n\n")
            }
        }

        escreva("--- FIM DE JOGO ---\n")
        escreva("Voc� conseguiu afundar ", acertos, " navio(s)!\n")
    }
}
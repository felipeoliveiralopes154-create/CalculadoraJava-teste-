programa{
    funcao inicio(){
        inteiro matriz[3][3]
        inteiro l, c

        para (l = 0; l < 3; l++){
            para (c = 0; c < 3; c++){
                se (l == c){
                    matriz[l][c] = 1
                }
                senao{
                    matriz[l][c] = 0
                }
            }
        }

        escreva("--- Matriz Identidade 3x3 ---\n")
        
        para (l = 0; l < 3; l++){
            para (c = 0; c < 3; c++){
                escreva("[ ", matriz[l][c], " ] ")
            }
            escreva("\n")
        }
    }
}
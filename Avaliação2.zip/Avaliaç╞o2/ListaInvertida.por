programa{
    funcao inicio(){
        cadeia nomes[5]
        inteiro i

        escreva("--- Leitura de Nomes ---\n")

        para (i = 0; i < 5; i++){
            escreva("Digite o ", i + 1, "� nome: ")
            leia(nomes[i])
        }

        escreva("\n--- Nomes na Ordem Inversa ---\n")

        para (i = 4; i >= 0; i--){
            escreva(nomes[i], "\n")
        }
    }
}
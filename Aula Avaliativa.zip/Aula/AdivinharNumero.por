programa
{
    funcao inicio(){
        inteiro numero_secreto = 42
        inteiro palpite

        escreva("=== JOGO DO N�MERO SECRETO ===\n")

        faca{
            escreva("Tente adivinhar o n�mero secreto: ")
            leia(palpite)

            se (palpite > numero_secreto){
                escreva("Dica: Muito Alto!\n\n")
            }
            senao se (palpite < numero_secreto){
                escreva("Dica: Muito Baixo!\n\n")
            }
            
        } enquanto (palpite != numero_secreto)

        escreva("Parab�ns! Voc� acertou, o n�mero secreto era ", numero_secreto, "!\n")
    }
}
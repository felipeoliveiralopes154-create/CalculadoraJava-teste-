programa
{
    funcao inicio(){
        real nota, soma = 0.0, media
        inteiro i

        para (i = 1; i <= 4; i++)
        {
            escreva("Digite a ", i, "� nota: ")
            leia(nota)

            enquanto (nota < 0.0 ou nota > 10.0)
            {
                escreva("Nota inv�lida! A nota deve ser entre 0 e 10.\n")
                escreva("Digite a ", i, "� nota novamente: ")
                leia(nota)
            }

            soma = soma + nota
        }

        media = soma / 4.0
        
        escreva("\nM�dia Final: ", media, "\n")

        se (media >= 7.0)
        {
            escreva("Situa��o: Aprovado\n")
        }
        senao
        {
            escreva("Situa��o: Reprovado\n")
        }
    }
}
programa
{
    funcao inicio(){
        inteiro numero, i, fatorial = 1

        escreva("Digite um n�mero para calcular o seu fatorial: ")
        leia(numero)

        para (i = numero; i >= 1; i--){
            fatorial = fatorial * i
        }

        escreva("\nResultado: ", numero, "! = ", fatorial, "\n")
    }
}
programa
{
    funcao inicio(){
        inteiro linhas, i, j

        escreva("Digite o n�mero de linhas para a pir�mide: ")
        leia(linhas)

        para (i = 1; i <= linhas; i++){
            para (j = 1; j <= i; j++){
                escreva(i, " ") 
            }
            
            escreva("\n")
        }
    }
}
programa
{
    funcao inicio(){
        inteiro numero, pares = 0, impares = 0, i
        para (i = 1; i <= 10; i++){
            escreva("Digite o ", i, "� n�mero inteiro: ")
            leia(numero)

            se (numero % 2 == 0){
                pares = pares + 1
            }
            senao
            {
                impares = impares + 1
            }
        }

        escreva("\n--- Resultados ---\n")
        escreva("Total de n�meros pares: ", pares, "\n")
        escreva("Total de n�meros �mpares: ", impares, "\n")
    }
}
programa
{
    funcao inicio(){
        inteiro idade, i

        para (i = 1; i <= 5; i++)
        {
            escreva("Digite a idade da ", i, "� pessoa: ")
            leia(idade)

            se (idade >= 18)
            {
                escreva("Maior de Idade\n\n")
            }
            senao{
                escreva("Menor de Idade\n\n")
            }
        }
    }
}
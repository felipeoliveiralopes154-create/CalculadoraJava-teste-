programa
{
    funcao inicio(){
        inteiro numero = 0, soma = 0

        escreva("Digite um n�mero (ou um valor negativo para encerrar): ")
        leia(numero)

        enquanto (numero >= 0)
        {
            soma = soma + numero
            
            escreva("Digite outro n�mero (ou um valor negativo para encerrar): ")
            leia(numero)
        }

        escreva("\nPrograma encerrado.")
        escreva("\nA soma de todos os n�meros positivos digitados �: ", soma, "\n")
    }
}
programa
{
    funcao inicio(){
        inteiro largura, altura, linha, coluna

        escreva("Digite a largura do ret�ngulo: ")
        leia(largura)
        
        escreva("Digite a altura do ret�ngulo: ")
        leia(altura)

        escreva("\nDesenhando o ret�ngulo:\n\n")

        para (linha = 1; linha <= altura; linha++){
            para (coluna = 1; coluna <= largura; coluna++){
                escreva("*")
            }
            
            escreva("\n")
        }
    }
}
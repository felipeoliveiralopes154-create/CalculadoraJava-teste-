programa
{
    funcao inicio(){
        inteiro opcao
        real n1, n2, resultado

        faca{
            escreva("\n--- MENU DE OPERA��ES ---")
            escreva("\n1 - Soma")
            escreva("\n2 - Subtra��o")
            escreva("\n0 - Sair")
            escreva("\nEscolha uma op��o: ")
            leia(opcao)

            escolha (opcao){
                caso 1:
                    escreva("Digite o primeiro n�mero: ")
                    leia(n1)
                    escreva("Digite o segundo n�mero: ")
                    leia(n2)
                    resultado = n1 + n2
                    escreva("Resultado da Soma: ", resultado, "\n")
                    pare
                
                caso 2:
                    escreva("Digite o primeiro n�mero: ")
                    leia(n1)
                    escreva("Digite o segundo n�mero: ")
                    leia(n2)
                    resultado = n1 - n2
                    escreva("Resultado da Subtra��o: ", resultado, "\n")
                    pare

                caso 0:
                    escreva("Saindo do programa...\n")
                    pare

                caso contrario:
                    escreva("Op��o inv�lida! Tente novamente.\n")
            }
            
        } enquanto (opcao != 0)
    }
}
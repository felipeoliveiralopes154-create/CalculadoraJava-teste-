programa
{
    funcao inicio(){
        inteiro numero, i, resultado

        escreva("=== GERADOR DE TABUADA ===\n")
        escreva("Digite o n�mero que voc� deseja ver a tabuada: ")
        leia(numero)

        escreva("\nTabuada do ", numero, ":\n")
        escreva("------------\n")

        para (i = 1; i <= 10; i++)
        {
            resultado = numero * i
            escreva(numero, " x ", i, " = ", resultado, "\n")
        }
        
        escreva("-------------\n")
    }
}